package com.stamford.pos22021

class MacaronAdapter {
}