package com.stamford.pos22021

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Product : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)
    }
}