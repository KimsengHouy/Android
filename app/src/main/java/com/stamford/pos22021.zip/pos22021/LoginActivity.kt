package com.stamford.pos22021


import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        // get reference to TextView
        val titleTextView = findViewById<TextView>(R.id.LoginTextView)
        titleTextView.setOnLongClickListener {
            val intent = Intent(this, SettingActivity::class.java)
            Log.v(TAG, "Setting Activity Detect");

            startActivity(intent)

            return@setOnLongClickListener true
        }

        // get reference to button
        val btnClickMe = findViewById<Button>(R.id.loginBtn)
// set on-click listener
        btnClickMe.setOnClickListener {
            Toast.makeText(this, "Kimseng has clicked the login button", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, OrderActivity::class.java)
            startActivity(intent)
        }
    }
}